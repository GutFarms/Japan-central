# CYD Companion (Windows)

USB mining control for the ESP32-2432S028. The **PC** talks to a Bitcoin stratum pool; the **board** only SHA-256 hashes work received over USB-C.

## Recommended download (all-in-one)

**`CYD-Miner-Setup.exe`** — Windows setup wizard with:

- CYD Companion app
- Firmware `esp32-2432s028-sha256-miner-merged.bin`
- `Flash-Firmware.bat` helper + flash docs
- Start Menu / Desktop shortcuts

Also available:

| Package | Contents |
|---------|----------|
| `CYD-Miner-Portable.zip` | Same kit, no installer |
| `CYD-Companion-App-Only.zip` | Just `cyd-companion.exe` |
| `CYD-Companion-Setup.exe` | Alias of the full miner setup |

## Build

```bash
./scripts/build-flash-images.sh
./scripts/build-companion-windows.sh
```

## Use

1. Run **CYD-Miner-Setup.exe** (or unpack the portable kit)
2. **Flash Firmware** once (merged.bin @ **0x0**)
3. Open **CYD Companion** → COM → **Connect**
4. Enter stratum / **Bitcoin address** / password → **Start mining**

## Recommended pool (ESP32-friendly)

| Field | Value |
|-------|--------|
| Stratum | `stratum+tcp://public-pool.io:21496` |
| Worker | Your **Bitcoin** address |
| Password | `x` |

Low share difficulty solo pool (NerdMiner-compatible). Finding a BTC block is a lottery.

Alternates: `pool.nerdminer.io:3333`, `pool.nerdminers.org:3333`

## Tabs

- **Mine** — USB, pool, live hashrate (kH/s), stratum TX/RX, logs
- **Debug / Terminal** — raw `cmp` commands to the board

## USB protocol

```text
cmp ping / status / config / clock / reboot / stop / bench
cmp jh <160hex> / jt <64hex> / ja job=&en2=&ntime=
cmp stats accepted=N&rejected=N
board → CMPSHARE nonce=…&job=…&en2=…&ntime=…
```
