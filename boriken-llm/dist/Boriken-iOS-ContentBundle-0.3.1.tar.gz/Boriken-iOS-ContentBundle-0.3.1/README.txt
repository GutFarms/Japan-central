Boriken iOS Content Bundle 0.3.1
====================================

1. In Xcode: File → Add Package Dependencies → Add Local → select BorikenKit/
2. Drag Corpus/ into your app target (Copy items if needed)
3. Optionally ship Model/boriken-gpt.pt for on-device completion research
4. Add BorikenHomeView.swift to a SwiftUI target, or call BorikenClient

Point BorikenClient at your API host, or use the Offline Learner zip for
zero-server practice on device (open index.html / Add to Home Screen).
