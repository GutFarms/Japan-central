CYD PC/GPU Monitor — firmware flash package
===========================================

Easiest flash (recommended):
  esptool.py --chip esp32 --port COMx --baud 921600 \
    write_flash 0x0 esp32-cyd-pc-monitor-merged.bin

Linux example:
  esptool.py --chip esp32 --port /dev/ttyUSB0 --baud 921600 \
    write_flash 0x0 esp32-cyd-pc-monitor-merged.bin

Install esptool if needed:
  pip install esptool

See FLASH.md for app-only / split flashing.
After flash, plug USB and run the host app from CYD-Monitor-portable.zip.
